import React from 'react';
import { ProcessedProfile } from '../types';

interface BodyMapProps {
  profiles: Record<string, ProcessedProfile>;
  onSelectProfile: (profileName: string) => void;
}

interface OrganDefinition {
  id: string;
  label: string;
  icon: string;
  labelX: number;
  labelY: number;
  mappedProfiles: string[];
}

const ORGANS: OrganDefinition[] = [
  {
    id: "thyroid",
    label: "Thyroid",
    icon: "🦋",
    labelX: 200,
    labelY: 115,
    mappedProfiles: ["Thyroid Profile"]
  },
  {
    id: "heart",
    label: "Heart",
    icon: "🫀",
    labelX: 200,
    labelY: 205,
    mappedProfiles: ["Lipid Profile"]
  },
  {
    id: "liver",
    label: "Liver",
    icon: "🥩",
    labelX: 235,
    labelY: 280,
    mappedProfiles: ["Liver Profile"]
  },
  {
    id: "pancreas",
    label: "Pancreas",
    icon: "📊",
    labelX: 200,
    labelY: 320,
    mappedProfiles: ["Diabetes Monitoring"]
  },
  {
    id: "kidneys",
    label: "Kidneys",
    icon: "🫘",
    labelX: 200,
    labelY: 375,
    mappedProfiles: ["Kidney Profile", "Electrolyte Profile"]
  },
  {
    id: "blood",
    label: "Blood & Immunity",
    icon: "🩸",
    labelX: 105,
    labelY: 260,
    mappedProfiles: ["Blood Counts", "Differential Counts", "Anemia Studies", "Vitamin Profile"]
  }
];

export const BodyMap: React.FC<BodyMapProps> = ({ profiles, onSelectProfile }) => {
  // Determine status & primary profile for an organ
  const getOrganStatus = (organ: OrganDefinition) => {
    let hasTests = false;
    let isAbnormal = false;
    let normalCount = 0;
    let abnormalCount = 0;
    let primaryProfile = organ.mappedProfiles[0];

    for (const pName of organ.mappedProfiles) {
      const p = profiles[pName];
      if (p) {
        hasTests = true;
        normalCount += p.normal_count;
        abnormalCount += p.abnormal_count;
        if (p.is_abnormal) {
          isAbnormal = true;
          primaryProfile = pName;
        }
      }
    }

    return { hasTests, isAbnormal, normalCount, abnormalCount, primaryProfile };
  };

  return (
    <div className="bg-gradient-to-b from-slate-50 via-blue-50/50 to-indigo-50/40 rounded-3xl p-5 border border-slate-200/80 shadow-sm relative overflow-hidden my-4">

      {/* Title Bar */}
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-200/60">
        <div>
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
            <span>🫀</span> Medical Human Anatomy Map
          </h3>
          <p className="text-[11px] text-slate-500 font-medium">
            Anatomically targeted organ evaluation based on laboratory parameters
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-2.5 text-[10px] font-bold bg-white/90 px-3 py-1 rounded-full border border-slate-200 shadow-2xs">
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Normal
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" /> Abnormal
          </span>
        </div>
      </div>

      {/* Main Vector Diagram Area */}
      <div className="relative min-h-[500px] flex items-center justify-center my-2 select-none">

        <svg
          viewBox="0 0 400 700"
          className="w-full max-w-[340px] h-auto drop-shadow-md transition-all"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Skin / Body Shading Gradients */}
            <linearGradient id="skinGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#F5D0C5" stopOpacity="0.35" />
              <stop offset="50%" stopColor="#E8B4A2" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#F5D0C5" stopOpacity="0.35" />
            </linearGradient>

            <linearGradient id="organNormalGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#34D399" stopOpacity="0.75" />
              <stop offset="100%" stopColor="#059669" stopOpacity="0.85" />
            </linearGradient>

            <linearGradient id="organAbnormalGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#F87171" stopOpacity="0.85" />
              <stop offset="100%" stopColor="#DC2626" stopOpacity="0.95" />
            </linearGradient>

            {/* Glow Filter for Active Abnormal Organs */}
            <filter id="organGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Background Ambient Mat */}
          <rect width="400" height="700" fill="#F8FAFC" rx="24" opacity="0.6" />

          {/* === ANATOMICALLY ACCURATE HUMAN BODY OUTLINE === */}
          {/* Head */}
          <ellipse cx="200" cy="55" rx="34" ry="40" fill="url(#skinGradient)" stroke="#C4A882" strokeWidth="1.5" opacity="0.7" />

          {/* Neck */}
          <path d="M 184 92 Q 200 102 216 92 L 216 118 Q 200 124 184 118 Z"
            fill="url(#skinGradient)" stroke="#C4A882" strokeWidth="1" opacity="0.6" />

          {/* Torso Silhouette */}
          <path d="M 136 122 Q 200 112 264 122 
                   L 274 158 Q 278 198 272 238 
                   L 266 318 Q 260 378 254 418 
                   L 248 498 Q 242 578 238 658
                   L 162 658 Q 158 578 152 498
                   L 146 418 Q 140 378 134 318
                   L 128 238 Q 122 198 126 158 Z"
            fill="url(#skinGradient)" stroke="#C4A882" strokeWidth="1.5" opacity="0.5" />

          {/* Arms (Medical Position) */}
          <path d="M 126 158 Q 96 198 90 278 Q 85 358 96 418"
            fill="none" stroke="#C4A882" strokeWidth="1.5" opacity="0.4" />
          <path d="M 274 158 Q 304 198 310 278 Q 315 358 304 418"
            fill="none" stroke="#C4A882" strokeWidth="1.5" opacity="0.4" />

          {/* Legs */}
          <path d="M 166 658 Q 160 708 156 750"
            fill="none" stroke="#C4A882" strokeWidth="1.5" opacity="0.4" />
          <path d="M 234 658 Q 240 708 244 750"
            fill="none" stroke="#C4A882" strokeWidth="1.5" opacity="0.4" />

          {/* Ribcage Details */}
          <path d="M 160 160 Q 200 175 240 160 M 155 180 Q 200 195 245 180 M 152 200 Q 200 215 248 200 M 155 220 Q 200 232 245 220"
            fill="none" stroke="#D4B5A0" strokeWidth="1" opacity="0.25" />

          {/* === INTERNAL ORGANS (ANATOMICALLY ACCURATE SHAPES & POSITIONS) === */}

          {/* 1. THYROID (Neck) */}
          {(() => {
            const { isAbnormal, primaryProfile } = getOrganStatus(ORGANS[0]);
            return (
              <g
                id="organ-thyroid"
                className="cursor-pointer transition-opacity hover:opacity-100"
                onClick={() => onSelectProfile(primaryProfile)}
                filter={isAbnormal ? "url(#organGlow)" : undefined}
              >
                <path d="M 186 110 Q 200 102 214 110 Q 220 120 214 126 Q 200 132 186 126 Q 180 120 186 110 Z"
                  fill={isAbnormal ? "url(#organAbnormalGrad)" : "url(#organNormalGrad)"}
                  stroke={isAbnormal ? "#DC2626" : "#059669"}
                  strokeWidth="1.5"
                  opacity="0.85" />
                <rect x="193" y="117" width="14" height="5" rx="2.5" fill={isAbnormal ? "#DC2626" : "#059669"} opacity="0.9" />
              </g>
            );
          })()}

          {/* 2. LUNGS (Background Chest) */}
          <g id="organ-lungs" opacity="0.4">
            <path d="M 205 165 Q 238 160 248 185 Q 252 215 247 245 Q 242 265 228 270 Q 214 265 209 245 Q 204 215 205 165 Z" fill="#FCA5A5" stroke="#F87171" strokeWidth="1" />
            <path d="M 195 165 Q 162 160 152 185 Q 148 215 153 245 Q 158 265 172 270 Q 186 265 191 245 Q 196 215 195 165 Z" fill="#FCA5A5" stroke="#F87171" strokeWidth="1" />
          </g>

          {/* 3. HEART (Center-Left Chest) */}
          {(() => {
            const { isAbnormal, primaryProfile } = getOrganStatus(ORGANS[1]);
            return (
              <g
                id="organ-heart"
                className="cursor-pointer transition-opacity hover:opacity-100"
                onClick={() => onSelectProfile(primaryProfile)}
                filter={isAbnormal ? "url(#organGlow)" : undefined}
              >
                <path d="M 180 180 C 170 170, 158 180, 163 195 C 165 205, 178 220, 200 235 C 222 220, 235 205, 237 195 C 242 180, 230 170, 220 180 C 210 185, 203 190, 200 195 C 197 190, 190 185, 180 180 Z"
                  fill={isAbnormal ? "url(#organAbnormalGrad)" : "url(#organNormalGrad)"}
                  stroke={isAbnormal ? "#DC2626" : "#059669"}
                  strokeWidth="1.5"
                  opacity="0.9" />
                {/* Aortic Arch details */}
                <path d="M 195 178 Q 200 170 205 178" fill="none" stroke={isAbnormal ? "#7F1D1D" : "#065F46"} strokeWidth="1.5" opacity="0.6" />
              </g>
            );
          })()}

          {/* 4. LIVER (Upper Right Abdomen) */}
          {(() => {
            const { isAbnormal, primaryProfile } = getOrganStatus(ORGANS[2]);
            return (
              <g
                id="organ-liver"
                className="cursor-pointer transition-opacity hover:opacity-100"
                onClick={() => onSelectProfile(primaryProfile)}
                filter={isAbnormal ? "url(#organGlow)" : undefined}
              >
                <path d="M 200 240 Q 230 235 250 250 Q 264 265 258 290 Q 252 310 232 315 Q 212 320 198 305 Q 192 290 194 270 Q 196 250 200 240 Z"
                  fill={isAbnormal ? "url(#organAbnormalGrad)" : "url(#organNormalGrad)"}
                  stroke={isAbnormal ? "#DC2626" : "#059669"}
                  strokeWidth="1.5"
                  opacity="0.85" />
                <path d="M 210 255 Q 230 260 240 275" fill="none" stroke={isAbnormal ? "#7F1D1D" : "#065F46"} strokeWidth="1" opacity="0.4" />
              </g>
            );
          })()}

          {/* 5. STOMACH (Upper Left Abdomen) */}
          <g id="organ-stomach" opacity="0.5">
            <path d="M 175 250 Q 165 255 160 270 Q 158 290 165 305 Q 175 315 190 310 Q 200 300 198 280 Q 195 260 185 253 Z"
              fill="#FDE68A" stroke="#F59E0B" strokeWidth="1" />
          </g>

          {/* 6. PANCREAS (Lower Center Abdomen) */}
          {(() => {
            const { isAbnormal, primaryProfile } = getOrganStatus(ORGANS[3]);
            return (
              <g
                id="organ-pancreas"
                className="cursor-pointer transition-opacity hover:opacity-100"
                onClick={() => onSelectProfile(primaryProfile)}
                filter={isAbnormal ? "url(#organGlow)" : undefined}
              >
                <path d="M 182 310 Q 208 305 228 312 Q 238 316 232 322 Q 218 326 198 324 Q 178 322 173 316 Z"
                  fill={isAbnormal ? "url(#organAbnormalGrad)" : "url(#organNormalGrad)"}
                  stroke={isAbnormal ? "#DC2626" : "#059669"}
                  strokeWidth="1.5"
                  opacity="0.85" />
              </g>
            );
          })()}

          {/* 7. KIDNEYS (Lower Back / Flank Region) */}
          {(() => {
            const { isAbnormal, primaryProfile } = getOrganStatus(ORGANS[4]);
            return (
              <g
                id="organ-kidneys"
                className="cursor-pointer transition-opacity hover:opacity-100"
                onClick={() => onSelectProfile(primaryProfile)}
                filter={isAbnormal ? "url(#organGlow)" : undefined}
              >
                {/* Right Kidney */}
                <path d="M 215 340 Q 230 335 240 345 Q 248 360 245 380 Q 240 395 225 398 Q 212 395 210 380 Q 208 365 215 340 Z"
                  fill={isAbnormal ? "url(#organAbnormalGrad)" : "url(#organNormalGrad)"}
                  stroke={isAbnormal ? "#DC2626" : "#059669"}
                  strokeWidth="1.5"
                  opacity="0.85" />
                {/* Left Kidney */}
                <path d="M 185 340 Q 170 335 160 345 Q 152 360 155 380 Q 160 395 175 398 Q 188 395 190 380 Q 192 365 185 340 Z"
                  fill={isAbnormal ? "url(#organAbnormalGrad)" : "url(#organNormalGrad)"}
                  stroke={isAbnormal ? "#DC2626" : "#059669"}
                  strokeWidth="1.5"
                  opacity="0.85" />
                {/* Hilum details */}
                <ellipse cx="228" cy="368" rx="4" ry="8" fill={isAbnormal ? "#7F1D1D" : "#065F46"} opacity="0.6" />
                <ellipse cx="172" cy="368" rx="4" ry="8" fill={isAbnormal ? "#7F1D1D" : "#065F46"} opacity="0.6" />
              </g>
            );
          })()}

          {/* 8. INTESTINES (Pelvic Bowl Background) */}
          <g id="organ-intestines" opacity="0.4">
            <path d="M 165 390 Q 200 385 235 390 Q 245 410 240 430 Q 230 450 200 455 Q 170 450 160 430 Q 155 410 165 390 Z"
              fill="#FED7AA" stroke="#F97316" strokeWidth="1" />
          </g>

          {/* 9. BLOOD / CIRCULATORY VASCULAR OVERLAY */}
          {(() => {
            const { isAbnormal, primaryProfile } = getOrganStatus(ORGANS[5]);
            return (
              <g
                id="organ-blood"
                className="cursor-pointer transition-opacity hover:opacity-100"
                onClick={() => onSelectProfile(primaryProfile)}
              >
                {/* Arm Vascular Streams */}
                <path d="M 120 195 Q 108 245 102 295" fill="none" stroke={isAbnormal ? "#DC2626" : "#059669"} strokeWidth="2.5" strokeDasharray="5,3" opacity="0.75" />
                <path d="M 280 195 Q 292 245 298 295" fill="none" stroke={isAbnormal ? "#DC2626" : "#059669"} strokeWidth="2.5" strokeDasharray="5,3" opacity="0.75" />
              </g>
            );
          })()}

          {/* === INTERACTIVE HOTSPOT PINS & BADGES FOR EACH ORGAN === */}
          {ORGANS.map((organ) => {
            const { hasTests, isAbnormal, abnormalCount, primaryProfile } = getOrganStatus(organ);

            if (!hasTests) return null;

            return (
              <g
                key={organ.id}
                className="cursor-pointer group"
                onClick={() => onSelectProfile(primaryProfile)}
              >
                {/* Dashed Indicator Ring */}
                <circle
                  cx={organ.labelX}
                  cy={organ.labelY}
                  r="18"
                  fill="none"
                  stroke={isAbnormal ? "#EF4444" : "#10B981"}
                  strokeWidth="2"
                  strokeDasharray="4,2"
                  className={isAbnormal ? "animate-spin" : undefined}
                  style={isAbnormal ? { animationDuration: '8s' } : undefined}
                />

                {/* Hotspot Center Pin */}
                <circle
                  cx={organ.labelX}
                  cy={organ.labelY}
                  r="13"
                  fill="#FFFFFF"
                  stroke={isAbnormal ? "#DC2626" : "#059669"}
                  strokeWidth="2"
                  className="shadow-md"
                />

                {/* Status Symbol inside Pin */}
                <text
                  x={organ.labelX}
                  y={organ.labelY + 4}
                  textAnchor="middle"
                  fill={isAbnormal ? "#DC2626" : "#059669"}
                  fontSize="12"
                  fontWeight="900"
                >
                  {isAbnormal ? "!" : "✓"}
                </text>

                {/* Abnormal Count Badge */}
                {isAbnormal && (
                  <g>
                    <circle
                      cx={organ.labelX + 13}
                      cy={organ.labelY - 11}
                      r="8"
                      fill="#DC2626"
                      stroke="#FFFFFF"
                      strokeWidth="1.5"
                    />
                    <text
                      x={organ.labelX + 13}
                      y={organ.labelY - 8}
                      textAnchor="middle"
                      fill="#FFFFFF"
                      fontSize="9"
                      fontWeight="900"
                    >
                      {abnormalCount}
                    </text>
                  </g>
                )}
              </g>
            );
          })}

        </svg>

        {/* HTML Floating Tooltip Cards for Mapped Organs */}
        <div className="absolute inset-0 pointer-events-none z-20">
          {ORGANS.map((organ) => {
            const { hasTests, isAbnormal, abnormalCount, primaryProfile } = getOrganStatus(organ);

            if (!hasTests) return null;

            // Map SVG coordinates to percentage positions
            const topPct = (organ.labelY / 700) * 100;
            const leftPct = (organ.labelX / 400) * 100;

            return (
              <div
                key={organ.id}
                style={{ top: `${topPct}%`, left: `${leftPct}%` }}
                onClick={() => onSelectProfile(primaryProfile)}
                className={`pointer-events-auto absolute -translate-x-1/2 mt-4 whitespace-nowrap px-2.5 py-1 rounded-xl shadow-md border text-[10px] font-bold flex items-center gap-1.5 transition-all duration-200 hover:scale-105 cursor-pointer z-30 ${isAbnormal
                    ? 'bg-rose-50/95 border-rose-300 text-rose-900 shadow-rose-200'
                    : 'bg-emerald-50/95 border-emerald-200 text-emerald-900 shadow-emerald-100'
                  }`}
              >
                <span>{organ.icon} {organ.label}</span>
                <span className={`px-1.5 py-0.2 rounded-full font-black text-[9px] ${isAbnormal ? 'bg-rose-200 text-rose-900' : 'bg-emerald-200 text-emerald-900'
                  }`}>
                  {isAbnormal ? `Abnormal: ${abnormalCount}` : 'Normal'}
                </span>
              </div>
            );
          })}
        </div>

      </div>

      {/* Footer Helper Note */}
      <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px] font-semibold text-slate-500">
        <span>Click any organ pin to open dedicated medical profile findings</span>
        <span className="text-blue-600 font-bold">Gray's Medical Anatomy Standard</span>
      </div>

    </div>
  );
};
