import React, { useState, useMemo } from 'react';
import { Search, X, ChevronDown, ChevronUp, Info, Activity, Filter, ChevronRight } from 'lucide-react';
import { ProcessedProfile, TestItem } from '../types';
import { RangeIndicatorBar } from './RangeIndicatorBar';
import { getTestExplanation } from '../data/explanations';

interface SmartViewTabProps {
  profiles: Record<string, ProcessedProfile>;
  selectedProfileName?: string | null;
}

export const SmartViewTab: React.FC<SmartViewTabProps> = ({ profiles, selectedProfileName }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [abnormalOnly, setAbnormalOnly] = useState(false);
  const [expandedProfiles, setExpandedProfiles] = useState<Set<string>>(() => {
    const initial = new Set<string>();
    // Auto expand profiles with abnormal tests
    for (const [name, p] of Object.entries(profiles)) {
      if (p.is_abnormal || name === selectedProfileName) {
        initial.add(name);
      }
    }
    return initial;
  });

  const [expandedTests, setExpandedTests] = useState<Set<string>>(new Set());
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);

  // Toggle profile accordion
  const toggleProfile = (profileName: string) => {
    setExpandedProfiles(prev => {
      const next = new Set(prev);
      if (next.has(profileName)) {
        next.delete(profileName);
      } else {
        next.add(profileName);
      }
      return next;
    });
  };

  // Toggle test row expansion
  const toggleTest = (testKey: string) => {
    setExpandedTests(prev => {
      const next = new Set(prev);
      if (next.has(testKey)) {
        next.delete(testKey);
      } else {
        next.add(testKey);
      }
      return next;
    });
  };

  // Filter profiles and tests based on search and abnormal filter
  const filteredProfiles = useMemo(() => {
    const result: Record<string, ProcessedProfile> = {};
    const query = searchQuery.toLowerCase().trim();

    for (const [pName, p] of Object.entries(profiles)) {
      let matchingTests = p.tests;

      // Filter abnormal only
      if (abnormalOnly) {
        matchingTests = matchingTests.filter(t => t.status !== 'NORMAL');
      }

      // Filter search query
      if (query) {
        matchingTests = matchingTests.filter(t =>
          t.test_name.toLowerCase().includes(query) ||
          t.raw_test_name.toLowerCase().includes(query) ||
          pName.toLowerCase().includes(query)
        );
      }

      if (matchingTests.length > 0 || (query && pName.toLowerCase().includes(query))) {
        result[pName] = {
          ...p,
          tests: matchingTests
        };
      }
    }

    return result;
  }, [profiles, searchQuery, abnormalOnly]);

  return (
    <div className="flex flex-col gap-5 my-2 pb-12">
      
      {/* 4.1 Search Bar & Filter Controls Toolbar */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
        
        {/* Search Bar */}
        <div className="md:col-span-8 relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
            <Search size={16} />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search parameters or tests (e.g. Urea, HbA1c, Creatinine)..."
            className="w-full pl-10 pr-10 py-3 rounded-2xl bg-white border border-slate-200 shadow-2xs text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* Filter Controls */}
        <div className="md:col-span-4 bg-white rounded-2xl p-2.5 px-4 border border-slate-200 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3 text-[11px] font-bold text-slate-600">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Normal
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> Abnormal
            </span>
          </div>

          <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
            <Filter size={13} className="text-slate-400" />
            <span>Abnormal Only</span>
            <div className="relative inline-block w-9 h-5 align-middle select-none">
              <input
                type="checkbox"
                checked={abnormalOnly}
                onChange={() => setAbnormalOnly(!abnormalOnly)}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-500" />
            </div>
          </label>
        </div>

      </div>

      {/* Profile Cards Accordion */}
      {Object.keys(filteredProfiles).length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center text-slate-500 my-4 border border-slate-200 shadow-xs">
          <Activity size={40} className="mx-auto text-slate-300 mb-3 stroke-1" />
          <p className="text-sm font-bold text-slate-800">No matching test parameters found</p>
          <p className="text-xs text-slate-400 mt-1">Try resetting the search query or turning off the abnormal filter.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {Object.entries(filteredProfiles).map(([profileName, profile]) => {
            const isExpanded = expandedProfiles.has(profileName);

            return (
              <div
                key={profileName}
                className={`bg-white rounded-3xl border shadow-xs transition-all overflow-hidden ${
                  profile.is_abnormal
                    ? 'border-l-4 border-l-rose-500 border-slate-200'
                    : 'border-l-4 border-l-emerald-500 border-slate-200'
                }`}
              >
                {/* Accordion Header */}
                <div
                  onClick={() => toggleProfile(profileName)}
                  className="p-4 md:px-6 flex items-center justify-between cursor-pointer select-none hover:bg-slate-50/70 transition-colors"
                >
                  <div className="flex items-center gap-3 md:gap-4">
                    <div className="w-11 h-11 rounded-2xl bg-slate-100 flex items-center justify-center text-2xl shadow-2xs shrink-0">
                      {profile.icon}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-extrabold text-slate-900 tracking-tight">
                          {profile.name}
                        </h4>

                        {/* Info Tooltip Icon */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveTooltip(activeTooltip === profileName ? null : profileName);
                          }}
                          aria-label={`Info about ${profile.name}`}
                          className="text-slate-400 hover:text-blue-600 transition-colors p-0.5"
                        >
                          <Info size={15} />
                        </button>
                      </div>

                      {/* Pill Badges */}
                      <div className="flex items-center gap-2 mt-1">
                        <span className="bg-emerald-100 text-emerald-800 text-xs font-extrabold px-2.5 py-0.5 rounded-full">
                          Normal: {profile.normal_count}
                        </span>
                        {profile.abnormal_count > 0 && (
                          <span className="bg-rose-100 text-rose-800 text-xs font-extrabold px-2.5 py-0.5 rounded-full animate-pulse">
                            Abnormal: {profile.abnormal_count}
                          </span>
                        )}
                        <span className="hidden sm:inline text-xs text-slate-400 font-medium ml-2">
                          {profile.description}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Expand Chevron */}
                  <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">
                    {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </div>
                </div>

                {/* Info Tooltip Popup */}
                {activeTooltip === profileName && (
                  <div className="mx-4 md:mx-6 mb-4 bg-blue-50/80 border border-blue-200 rounded-2xl p-4 text-xs text-blue-900 font-medium">
                    <p className="font-bold text-sm mb-1">{profile.name} Medical Scope:</p>
                    <p className="leading-relaxed">{profile.description}</p>
                  </div>
                )}

                {/* Expanded Table State */}
                {isExpanded && (
                  <div className="border-t border-slate-100">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-slate-50/80 text-[11px] uppercase font-bold text-slate-400 border-b border-slate-100">
                            <th className="py-3 px-4 md:px-6">Test Name</th>
                            <th className="py-3 px-4 text-right">Result</th>
                            <th className="py-3 px-3">Unit</th>
                            <th className="py-3 px-4">Reference Range</th>
                            <th className="py-3 px-3 text-center">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-xs md:text-sm">
                          {profile.tests.map((test, idx) => {
                            const testKey = `${profileName}-${test.test_name}-${idx}`;
                            const isTestExpanded = expandedTests.has(testKey);
                            const isAbnormal = test.status !== 'NORMAL';

                            return (
                              <React.Fragment key={testKey}>
                                {/* Main Test Row */}
                                <tr
                                  onClick={() => toggleTest(testKey)}
                                  className={`cursor-pointer transition-colors hover:bg-slate-50/80 ${
                                    isTestExpanded ? 'bg-blue-50/40' : ''
                                  }`}
                                >
                                  {/* Test Name */}
                                  <td className="py-3.5 px-4 md:px-6 font-bold text-slate-900 flex items-center gap-2">
                                    <ChevronRight
                                      size={16}
                                      className={`text-slate-400 transition-transform shrink-0 ${
                                        isTestExpanded ? 'rotate-90 text-blue-600' : ''
                                      }`}
                                    />
                                    <span>{test.test_name}</span>
                                  </td>

                                  {/* Result Value */}
                                  <td className={`py-3.5 px-4 text-right font-black ${
                                    isAbnormal ? 'text-rose-600 text-base' : 'text-emerald-600'
                                  }`}>
                                    {test.value}
                                  </td>

                                  {/* Unit */}
                                  <td className="py-3.5 px-3 text-slate-500 font-medium text-xs">
                                    {test.raw_unit || '-'}
                                  </td>

                                  {/* Range */}
                                  <td className="py-3.5 px-4 text-slate-600 font-medium text-xs">
                                    {test.reference_range.raw || (
                                      test.reference_range.low !== null && test.reference_range.high !== null
                                        ? `${test.reference_range.low} - ${test.reference_range.high}`
                                        : '-'
                                    )}
                                  </td>

                                  {/* Status Dot */}
                                  <td className="py-3.5 px-3 text-center">
                                    <span className={`inline-block w-3 h-3 rounded-full ${
                                      isAbnormal ? 'bg-rose-500 shadow-rose-300 animate-pulse' : 'bg-emerald-500'
                                    }`} />
                                  </td>
                                </tr>

                                {/* Expanded Explanation Drawer Row (Desktop Grid View) */}
                                {isTestExpanded && (
                                  <tr>
                                    <td colSpan={5} className="bg-slate-50/90 p-4 md:p-6 border-t border-b border-blue-100">
                                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                                        
                                        {/* Visual Indicator Bar (Left/Top Column) */}
                                        <div className="lg:col-span-6">
                                          <div className="flex items-center gap-2 mb-2">
                                            <span className="font-extrabold text-sm text-slate-900">
                                              {test.test_name}
                                            </span>
                                            <span className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold ${
                                              isAbnormal ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                                            }`}>
                                              {test.status}
                                            </span>
                                          </div>

                                          <RangeIndicatorBar
                                            value={test.value}
                                            unit={test.raw_unit}
                                            range={test.reference_range}
                                            status={test.status}
                                          />
                                        </div>

                                        {/* Plain Language Explanation Card (Right/Bottom Column) */}
                                        <div className="lg:col-span-6">
                                          {(() => {
                                            const explanation = getTestExplanation(test.test_name, test.status);
                                            return (
                                              <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs text-xs md:text-sm space-y-3">
                                                <div>
                                                  <span className="font-extrabold text-blue-900 block mb-0.5">
                                                    What is this test?
                                                  </span>
                                                  <span className="text-slate-700 font-medium leading-relaxed">
                                                    {explanation.what} {explanation.function}
                                                  </span>
                                                </div>

                                                <div className="pt-2.5 border-t border-slate-100">
                                                  <span className="font-extrabold text-slate-900 block mb-0.5">
                                                    Clinical Interpretation:
                                                  </span>
                                                  <span className={`font-semibold leading-relaxed block ${
                                                    test.status === 'HIGH' ? 'text-rose-700' :
                                                    test.status === 'LOW' ? 'text-rose-700' :
                                                    'text-emerald-700'
                                                  }`}>
                                                    {test.status === 'HIGH' ? explanation.high_meaning || explanation.meaning :
                                                     test.status === 'LOW' ? explanation.low_meaning || explanation.meaning :
                                                     'Your test result is within normal expected reference boundaries.'}
                                                  </span>
                                                </div>
                                              </div>
                                            );
                                          })()}
                                        </div>

                                      </div>
                                    </td>
                                  </tr>
                                )}
                              </React.Fragment>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
