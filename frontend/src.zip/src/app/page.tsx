'use client';

import React, { useState, useMemo, ChangeEvent } from 'react';
import { HeaderBar } from '../components/HeaderBar';
import { TabNavigation } from '../components/TabNavigation';
import { WellnessScoreCard } from '../components/WellnessScoreCard';
import { BodyMap } from '../components/BodyMap';
import { DietRecommendationsSection } from '../components/DietRecommendationsSection';
import { RiskCalculatorSection } from '../components/RiskCalculatorSection';
import { SmartViewTab } from '../components/SmartViewTab';
import { LabReportResponse, TestItem } from '../types';
import {
  groupTestsIntoProfiles,
  calculateWellnessScore,
  calculateRisks,
  generateDietRecommendations
} from '../utils/healthCalculators';
import { Upload, FileText, Sparkles, CheckCircle2, AlertCircle, RefreshCw, FileUp, ShieldCheck, Cpu, Activity, Utensils, HeartPulse } from 'lucide-react';

// Normalize backend API payload safely into frontend LabReportResponse
function normalizeBackendResponse(rawJson: any): LabReportResponse {
  const data = rawJson.data || {};
  const report = data.report || {};
  const patient = data.patient || {};
  const rawTests = data.tests || [];

  const normalizedTests: TestItem[] = rawTests.map((t: any) => {
    const rangeObj = t.reference_range || {};
    const lowVal = typeof rangeObj.low === 'number' ? rangeObj.low : null;
    const highVal = typeof rangeObj.high === 'number' ? rangeObj.high : null;
    let rawVal = rangeObj.raw || '';

    if (!rawVal && lowVal !== null && highVal !== null) {
      rawVal = `${lowVal} - ${highVal}`;
    }

    return {
      test_name: t.test_name || t.canonical_test_name || t.raw_test_name || 'Lab Test',
      raw_test_name: t.raw_test_name || t.test_name || '',
      loinc_code: t.loinc_code || null,
      value: typeof t.value === 'number' ? t.value : (parseFloat(t.raw_value || t.value) || 0),
      raw_unit: t.raw_unit || t.normalized_unit || null,
      reference_range: {
        low: lowVal,
        high: highVal,
        raw: rawVal
      },
      status: (t.status || 'NORMAL').toUpperCase() as any,
      flag: (t.flag || 'NONE').toUpperCase() as any,
      source_trace: t.source_trace || { raw_test_name: t.raw_test_name || '', raw_value: String(t.value || '') }
    };
  });

  return {
    report_id: rawJson.report_id || report.report_id || `REP-${Date.now()}`,
    status: rawJson.status || 'VALIDATED',
    data: {
      schema_version: data.schema_version || '2.1',
      report: {
        report_id: report.report_id || `REP-${Date.now()}`,
        report_date: report.report_date || new Date().toISOString(),
        lab_name: report.lab_name || 'Diagnostic Laboratory'
      },
      patient: {
        patient_id: patient.patient_id || 'PAT-UPLOADED',
        name: patient.name || 'Patient Report',
        age: patient.age || 45,
        gender: patient.gender || 'Male'
      },
      tests: normalizedTests,
      warnings: data.warnings || [],
      completeness: data.completeness || {
        expected_count: normalizedTests.length,
        extracted_count: normalizedTests.length,
        missing_tests: [],
        unexpected_tests: [],
        complete: true
      }
    }
  };
}

export default function SmartHealthReportApp() {
  const [activeReport, setActiveReport] = useState<LabReportResponse | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'smart-view'>('overview');
  const [selectedProfileName, setSelectedProfileName] = useState<string | null>(null);
  const [uploading, setUploading] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Extract tests from active report
  const tests = useMemo(() => activeReport?.data?.tests || [], [activeReport]);
  const patient = useMemo(() => activeReport?.data?.patient || { patient_id: '', name: 'Patient', age: 0, gender: 'Male' as const }, [activeReport]);
  const report = useMemo(() => activeReport?.data?.report || { report_id: '', report_date: new Date().toISOString(), lab_name: 'Lab' }, [activeReport]);

  // Processed Data Computations
  const profiles = useMemo(() => groupTestsIntoProfiles(tests), [tests]);
  const wellnessScore = useMemo(() => calculateWellnessScore(tests), [tests]);
  const risks = useMemo(() => calculateRisks(tests, profiles), [tests, profiles]);
  const dietRecommendations = useMemo(() => generateDietRecommendations(profiles), [profiles]);

  // Handle PDF Upload to FastAPI Backend API
  const handleFileUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setUploadError(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
      const endpoints = [
        `${apiBaseUrl}/api/reports/upload`,
        `${apiBaseUrl}/api/v1/reports/upload`,
        `http://127.0.0.1:8000/api/reports/upload`,
        `http://localhost:8000/api/reports/upload`
      ];

      let response: Response | null = null;
      let lastError = '';

      for (const endpoint of endpoints) {
        try {
          response = await fetch(endpoint, {
            method: 'POST',
            body: formData
          });
          if (response.ok) break;
          lastError = `Endpoint ${endpoint} returned status ${response.status}`;
        } catch (err: any) {
          lastError = err.message || 'Network error';
        }
      }

      if (!response || !response.ok) {
        throw new Error(lastError || 'Could not connect to FastAPI backend server. Ensure backend server is running on port 8000.');
      }

      const json = await response.json();

      if (json && (json.data || json.tests)) {
        const normalized = normalizeBackendResponse(json);
        setActiveReport(normalized);
        setActiveTab('overview');
      } else {
        throw new Error('Unrecognized JSON payload returned from backend server.');
      }
    } catch (err: any) {
      console.error('PDF upload error:', err);
      setUploadError(err.message || 'Failed to parse lab report PDF. Please upload a valid laboratory report document.');
    } finally {
      setUploading(false);
    }
  };

  const handleSelectProfileFromOrgan = (profileName: string) => {
    setSelectedProfileName(profileName);
    setActiveTab('smart-view');
  };

  // State 1: Upload Hero View (When no report is active)
  if (!activeReport) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col justify-between selection:bg-blue-500 selection:text-white">

        {/* Minimal Header */}
        <header className="bg-white border-b border-gray-100 py-3.5 px-4 md:px-6 sticky top-0 z-40 shadow-xs">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-md">
                N
              </div>
              <span className="text-base font-black tracking-tight text-blue-900">
                Here<span className="text-blue-600">Click</span> <span className="text-xs font-semibold text-gray-400">SmartApp</span>
              </span>
            </div>
            <span className="text-xs font-extrabold bg-blue-50 text-blue-700 px-3 py-1 rounded-full border border-blue-200">
              FastAPI Pipeline Connected
            </span>
          </div>
        </header>

        {/* Upload Hero Section */}
        <main className="flex-1 flex flex-col items-center justify-center px-4 md:px-6 py-12 max-w-4xl mx-auto w-full">

          <div className="bg-white rounded-3xl p-6 md:p-10 border border-gray-200 shadow-xl w-full text-center relative overflow-hidden">

            {/* Background Aura */}
            <div className="absolute -top-20 -right-20 w-48 h-48 bg-blue-100/60 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col items-center gap-6">

              {/* Icon */}
              <div className="w-24 h-24 rounded-3xl bg-blue-50 border-2 border-blue-200 text-blue-600 flex items-center justify-center shadow-inner my-2">
                {uploading ? (
                  <RefreshCw size={44} className="animate-spin text-blue-600" />
                ) : (
                  <FileUp size={44} className="stroke-[1.75]" />
                )}
              </div>

              <div className="max-w-xl">
                <h1 className="text-2xl md:text-3xl font-black text-blue-950 tracking-tight">
                  {uploading ? 'Parsing Lab Report PDF...' : 'Upload Laboratory PDF Report'}
                </h1>
                <p className="text-sm text-gray-500 font-medium mt-2 leading-relaxed">
                  {uploading
                    ? 'Extracting OCR text, mapping biomarkers, and calculating wellness profiles via FastAPI backend...'
                    : 'Transform your laboratory blood test PDF into an interactive, patient-friendly Smart Health Dashboard.'}
                </p>
              </div>

              {/* Upload Dropzone Button */}
              <label className={`w-full max-w-md my-2 py-4 px-6 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-extrabold text-base flex items-center justify-center gap-3 cursor-pointer shadow-xl transition-all transform active:scale-98 ${uploading ? 'opacity-60 cursor-wait pointer-events-none' : ''
                }`}>
                <Upload size={20} />
                <span>{uploading ? 'Processing Extraction...' : 'Select PDF or Image Report'}</span>
                <input
                  type="file"
                  accept=".pdf,image/*"
                  onChange={handleFileUpload}
                  disabled={uploading}
                  className="hidden"
                />
              </label>

              {/* Error Display */}
              {uploadError && (
                <div className="bg-rose-50 border border-rose-200 text-rose-900 rounded-2xl p-4 text-xs md:text-sm text-left flex items-start gap-3 max-w-md w-full">
                  <AlertCircle size={18} className="text-rose-600 shrink-0 mt-0.5" />
                  <span className="font-semibold">{uploadError}</span>
                </div>
              )}

              {/* Desktop Features Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-gray-100 w-full text-left">
                <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
                  <Cpu size={16} className="text-blue-600 shrink-0" />
                  <span>Deterministic Parsing</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
                  <Activity size={16} className="text-emerald-600 shrink-0" />
                  <span>Interactive Organ Map</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
                  <HeartPulse size={16} className="text-rose-600 shrink-0" />
                  <span>Clinical Risk Meters</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
                  <Utensils size={16} className="text-purple-600 shrink-0" />
                  <span>Diet & Lifestyle Advice</span>
                </div>
              </div>

            </div>

          </div>

        </main>

        {/* Footer */}
        <footer className="py-4 text-center text-xs text-gray-400 font-medium border-t border-gray-100 bg-white">
          Powered by Blood Test Intelligence Engine • Confidential & Local Processing
        </footer>

      </div>
    );
  }

  // State 2: Active report extracted from backend -> Desktop Responsive Smart Health Viewer
  return (
    <div className="min-h-screen bg-slate-50/80 text-slate-900 font-sans pb-20 selection:bg-blue-500 selection:text-white">

      {/* Fixed Top Header Bar */}
      <HeaderBar
        patient={patient}
        report={report}
        status={activeReport.status}
        onUploadNewPdf={() => {
          // Trigger file input click
          const input = document.createElement('input');
          input.type = 'file';
          input.accept = '.pdf,image/*';
          input.onchange = (e: any) => handleFileUpload(e);
          input.click();
        }}
      />

      {/* Main Container - Responsive Desktop Layout (max-w-7xl) */}
      <main className="pt-20 px-4 md:px-6 max-w-7xl mx-auto min-h-screen">

        {/* Upload Status Banner */}
        <div className="mb-4 bg-white rounded-2xl p-3 px-4 border border-gray-200/80 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            <span className="text-xs md:text-sm font-extrabold text-slate-800">
              {patient.name} — Report Analyzed ({tests.length} Laboratory Parameters Extracted)
            </span>
          </div>

          {/* Re-upload Button for Mobile/Desktop */}
          <label className="text-xs font-extrabold text-blue-700 bg-blue-50 hover:bg-blue-100 px-3.5 py-1.5 rounded-xl border border-blue-200 cursor-pointer flex items-center gap-1.5 transition-all shrink-0">
            <Upload size={13} />
            <span>Upload New Report</span>
            <input
              type="file"
              accept=".pdf,image/*"
              onChange={handleFileUpload}
              disabled={uploading}
              className="hidden"
            />
          </label>
        </div>

        {/* Sticky Tab Navigation Bar */}
        <TabNavigation
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          abnormalCount={wellnessScore.abnormal}
        />

        {/* TAB CONTENT: OVERVIEW TAB (DESKTOP TWO-COLUMN GRID) */}
        {activeTab === 'overview' && (
          <div className="animate-fadeIn my-4">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

              {/* Left Column (Sticky Sidebar on Desktop: Wellness Score + Organ Map) */}
              <div className="lg:col-span-5 flex flex-col gap-6 lg:sticky lg:top-36">
                {/* 3.1 Wellness Score Card */}
                <WellnessScoreCard scoreData={wellnessScore} />

                {/* 3.2 Interactive Body Map / Organ Diagram */}
                <BodyMap
                  profiles={profiles}
                  onSelectProfile={handleSelectProfileFromOrgan}
                />
              </div>

              {/* Right Column (Clinical Risk Assessment + Diet & Lifestyle Guidance) */}
              <div className="lg:col-span-7 flex flex-col gap-6">
                {/* 3.4 Clinical Risk Calculator Section */}
                <RiskCalculatorSection
                  risks={risks}
                  onSelectProfile={handleSelectProfileFromOrgan}
                />

                {/* 3.3 Diet Recommendations Section */}
                <DietRecommendationsSection recommendations={dietRecommendations} />
              </div>

            </div>
          </div>
        )}

        {/* TAB CONTENT: SMART VIEW TAB (FULL WIDTH DESKTOP TABLE & RANGE BARS) */}
        {activeTab === 'smart-view' && (
          <div className="animate-fadeIn my-4">
            <SmartViewTab
              profiles={profiles}
              selectedProfileName={selectedProfileName}
            />
          </div>
        )}

      </main>

      {/* Bottom Sticky Smart Banner */}
      <footer className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-gray-200 py-3 px-4 md:px-6 text-center shadow-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs text-gray-500 font-medium">
          <span className="font-semibold text-slate-700">NirogGyan Smart Health Dashboard</span>
          <span className="font-bold text-blue-600">Deterministic FastAPI Backend Connected</span>
        </div>
      </footer>

    </div>
  );
}
